<!DOCTYPE html>
<html>
<head>
<title>ASSIGNMENT 7</title>
</head>
<body>
<link rel="stylesheet" href="19bce7024.css">
<?php

$nameerr = $emailerr = $messageerr = $gendererr = $cnoerr = $passerr = $cpasserr = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $nameerr=$_POST["name"];
        $emailerr=$_POST["email"];
        $passerr=$_POST["password"];
        $cpasserr=$_POST["cpassword"];
        $messageerr=$_POST["message"];
        $cnoerr=$_POST["cno"];
        $gendererr=$_POST["gender"];
        if(isset($_POST['s'])){
            if(empty($nameerr)||empty($emailerr)||empty($passerr)||empty($cpasserr)||empty($messageerr)||empty($gendererr)){
                echo "no field should be empty <br>";
            }
            else if(preg_match ("/[0-9]/", $nameerr))
            {
                echo "Name field must not contain any digits<br>";
            }
            else if(!filter_var($emailerr, FILTER_VALIDATE_EMAIL))
            {
                echo "Email must be a valid one<br>";
            }
            else if(strlen($passerr)<8)
            {
                echo "Password field must have at least 8 characters long<br>";
            }
            else if(strcmp($passerr,$cpasserr)!=0){
                echo "Password and confirm password must match <br>";
            }
            else if(strlen($cnoerr)!=10 && !preg_match ("/^[0-9]*$/", $cnoerr))
            {
                echo "Contact number must be of 10 digits only.<br>";
            }
            else if(strlen($messageerr)>50)
            {
                echo "Message must be less than 50 characters<br>";
            }
            else{
                header('location:19bce7024_validation_success.php');
                exit();
            }

        }
        if(isset($_POST['r'])){
        $nameerr="";
        $emailerr="";
        $passerr="";
        $cpasserr="";
        $messageerr="";
        $gendererr="";
        $cnoerr="";

        }
    }
?>
<form method="post" action="">
Name<input type="text" name="name" ><span id="err">*<?php echo $nameerr; ?></span><br>
Email<input type="text" name="email" ><span id="err">*<?php echo $emailerr; ?></span><br>
Password<input type="password" name="password" ><span id="err">*<?php echo $passerr; ?></span><br>
C Password<input type="password" name="cpassword" ><span id="err">*<?php echo $cpasserr; ?></span><br>
Gender<input type="radio" name="gender" value="male"><label for="male">Male</label>
<input type="radio" name="gender" value="female"><label for="female">Female</label><span id="err">*<?php echo $gendererr; ?></span><br>
Contact no<input type="text" name="cno"><span id="err">*<?php echo $cnoerr; ?></span><br>
Message<textarea name="message" rows="5" columns="8"></textarea><span id="err">*<?php echo $messageerr; ?></span><br>
<input type="submit" name="s" value="Submit" action="">
<input type="submit" name="r" value="Reset" action="">

</body>
</html>
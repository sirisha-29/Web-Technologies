<?php
// Connecting to the Database
$servername = "localhost";
$username = "siri";
$password = "sirisha";
$database = "db_vit_19bce7024";

// Create a connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Die if connection was not successful
if (!$conn){
    die("Sorry we failed to connect: ". mysqli_connect_error());
}
else{
    echo "Connection was successful<br>";
}


// Create a table in the db
$sql = "CREATE TABLE 19bce7024_users
( 
    uname VARCHAR(15) NOT NULL,
    passwords VARCHAR(30) NOT NULL, 
    email VARCHAR(30) NOT NULL,
    dob VARCHAR(20) NOT NULL,
    PRIMARY KEY (uname)
)";


$result = mysqli_query($conn, $sql);

// Check for the table creation success
if($result){
    echo "The table cse_student got  created successfully!<br>";
}
else{
    echo "The table was not created successfully because of this error ---> ". mysqli_error($conn);
}
  
?>

<!DOCTYPE html>
<head>
<title>ASSIGNMENT 9</title>
<link rel="stylesheet" href="s19bce7024.css">
</head>
<body>

<?php
     $uname="";
     $pass="";
     $unErr="";
     $pErr= "";
     $error=""; 
     $errors="";
     $message= "";
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        include 'C:\xampp\htdocs\form\2connection.php';

        $uname=$_POST['uname'];
        $pass=$_POST['pass'];
            $valid=TRUE;
            if(empty($_POST["uname"])){
                $valid=FALSE;
            $unErr="NAME IS REQUIRED";
        }
        if(empty($_POST['pass'])){
            $valid=FALSE;
            $pErr="password must be filled";
        }
        if($valid)
        {
           
            $servername = "127.0.0.1";
            $username = "siri";
            $password = "sirisha";
            $database="db_vit_19BCE7024";
            $conn = mysqli_connect($servername, $username, $password,$database);
            session_start();
            $uname = mysqli_real_escape_string($conn, $_REQUEST['uname']);
            $pass = mysqli_real_escape_string($conn, $_REQUEST['pass']);
           
           
              
                $sql="SELECT uname,passwords FROM 19BCE7024_users WHERE uname='$uname' and passwords = '$pass'";
                $result = mysqli_query($conn,$sql);
                $row = $result -> fetch_array(MYSQLI_ASSOC);
                $active = $row['active'];
                $count  = mysqli_num_rows($result);
                
                if($count>=1) {
                    $_SESSION['login_user'] = $uname;
                        
                    
                    header('location:19BCE7024_login_success.php');
                   exit();
                } else {
                    
                    $message = "Invalid Username or Password!";
                        
                
                }
             
        }
        
            
    }
?>
<div class="container">
<form method="POST" action="">
<label>Username :</label><input type="text" name="uname"><span id="s">*<?php echo $unErr; ?> <?php echo $error; echo $errors; ?></span><br><br>
<label>Password :</label><input type="password" name="pass"><span id="s">* <?php echo $pErr; ?></span><br><br>
<input type="submit" id="b"><br><span><?php echo $message; ?></span><br><br>
</form>
</div>
</body>
</html>
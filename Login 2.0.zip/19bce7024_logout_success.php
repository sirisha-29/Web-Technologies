<?php 
session_start();
session_unset();
session_destroy();
$a="Thank You. You Have Successfully Logged Out:)";



?>

<!DOCTYPE html>
<html>
	<head>
		
		<style>
            * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body{
    background-color:deepskyblue;
}
.container {
    margin-top: 5%;
    background-color: rgb(235, 135, 157);
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}
div {
    display: block;
}
            #black{
                    color:black;
                    margin-left:0px;
            }
            
            </style>
	</head>
<body >
    <div class="container">
<span id="black"><?php echo $a;  ?></span></div>

</body>
</html>
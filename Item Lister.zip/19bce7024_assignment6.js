let e = document.getElementById('e');
let li = document.getElementById('list');
let item = document.getElementsByTagName('li');
array[x] = document.getElementById("e").value;
function submit() {
    if(e.value== '')
    {
        alert("Enter The text");   
    }
    else if(!isNaN(e.value))
    {
        alert("numbers are not allowed");
    }
        else
        {
        let node = document.createElement("li");
        let textnode = document.createTextNode(e.value);
        node.appendChild(textnode);
       let p= li.appendChild(node);
       let btn = document.createElement("button");   
       btn.innerHTML = " x ";                  
     let b= p.appendChild(btn); 
     b.style.background="red";
     b.style.borderColor="black";
     b.style.float="right";
     b.style.width="20px";
     btn.addEventListener("click",b);
        }
}
function reverse() {
    var  num=document.getElementsByTagName('li').length;
          var kids = li.childNodes;  
          for(var i = num; i >= 0; i--) {  
              var c = li.removeChild(kids[i]);   
              li.appendChild(c);    
            }              
  }  
  function b() { 
    if(item.length>0){
     if(confirm("ARE YOU SURE YOU WANT TO DELETE")) {    
     li.removeChild(li.lastElementChild);
    }      
else{
  alert("DELETED");
   }
  }
}